package com.hemonexus;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest(classes = HemoNexusApplication.class)
class HemoNexusApplicationTests {

    @Test
    void contextLoads() {
        // This empty test method just verifies that the Spring context loads
        // successfully
    }
}