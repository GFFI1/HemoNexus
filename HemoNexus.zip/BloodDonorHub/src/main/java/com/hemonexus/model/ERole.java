package com.hemonexus.model;

public enum ERole {
    ROLE_USER,
    ROLE_MODERATOR,
    ROLE_ADMIN,
    ROLE_BLOOD_BANK_ADMIN
}